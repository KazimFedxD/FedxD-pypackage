from FedxD import color
from FedxD import converters
from FedxD import random
from FedxD import excel
from FedxD import discord
from FedxD import pygame

print("('FedxD')Package Initialized Successfully")